package com.vardhancreations.customspinnernlistview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class CustomSpinnerAdapter extends BaseAdapter {

    private String[] dataSet;
    private LayoutInflater inflater;
    private int layout;
    private int[] fruitCount;
    public CustomSpinnerAdapter(@NonNull Context context, int resource, String[] dataSet, int[] fruitCount) {
        super();
        this.dataSet = dataSet;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        layout = resource;
        this.fruitCount = fruitCount;
    }

    @Override
    public int getCount() {
        return dataSet.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View customListItemView = inflater.inflate(layout, null);
        TextView tvName = customListItemView.findViewById(R.id.tvName);
        TextView tvCount = customListItemView.findViewById(R.id.tvCount);
        tvCount.setText(""+fruitCount[position]);
        tvName.setText(dataSet[position]);
        return customListItemView;
    }
}
