package com.vardhancreations.customspinnernlistview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private Spinner spinner;
    private ListView listFruits;
    private String[] fruits={"select a fruit","apple","banana","mango","grapes"};
    private int[] fruitCount={0,3,5,10,8};
    private int[] steps={1000,3450,1678,2800,1200};
    private int[] fruitImages={R.mipmap.fruit_basket,R.mipmap.apple,R.mipmap.banana,R.mipmap.mango,R.mipmap.grapes};
    private ArrayList<String> fruitsList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner = findViewById(R.id.spFruits);
        listFruits = findViewById(R.id.listFruits);



        CustomAdapter customAdapter = new CustomAdapter(MainActivity.this, R.layout.custom_listview,fruits,steps);
        listFruits.setAdapter(customAdapter);

//        MyAdapter myAdapter = new MyAdapter(MainActivity.this, R.layout.custom_listview, fruits, fruitImages);
//        spinner.setAdapter(myAdapter);

        CustomSpinnerAdapter customSpinnerAdapter=new CustomSpinnerAdapter(MainActivity.this,R.layout.custom_spinner,fruits,fruitCount);
        spinner.setAdapter(customSpinnerAdapter);

    }
}