package com.vardhancreations.customspinnernlistview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class CustomAdapter extends ArrayAdapter {
        private String dataSet[];
        private int steps[];
        private int layout;
        private LayoutInflater inflater;
    public CustomAdapter(@NonNull Context context, int resource, String fruits[], int[] steps) {
            super(context, resource);
            dataSet = fruits;
            layout = resource;
            this.steps = steps;
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }
        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            // This method is called once per each item in the dataset / list
            View customView = inflater.inflate(layout, null);
            TextView tvName = customView.findViewById(R.id.tvName);
            TextView imgItem = customView.findViewById(R.id.tvSteps);
            imgItem.setText(steps[position]+"");
            tvName.setText(dataSet[position]);
            return customView;
        }
        @Override
        public int getCount() {
            return dataSet.length;
        }
        @Nullable
        @Override
        public String getItem(int position) {
            return position+"";
        }
    }

