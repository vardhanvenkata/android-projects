package com.vardhancreations.apicallingdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    private TextView tvResponse;
    private Button btNext;
    private String API_URL = "https://jsonplaceholder.typicode.com/todos";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvResponse = findViewById(R.id.tvData);
        btNext = findViewById(R.id.btNext);
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,FirstActivity.class);
                startActivity(intent);
            }
        });
        findViewById(R.id.btGet).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new CallAPITask().execute();
            }
        });
    }
    class CallAPITask extends AsyncTask<Void, Void, String>{
        @Override
        protected String doInBackground(Void... voids) {
            String response = callAPI();
            System.out.println("=======> "+ response);
            return response;
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            tvResponse.setText(s);
        }
    }
    private String callAPI()
    {
        HttpURLConnection urlConnection = null;
        String response = null;
        try {
            URL url = new URL(API_URL);
            urlConnection = (HttpURLConnection) url.openConnection();
            BufferedReader br = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            // use a string builder to bufferize the response body
            // read from the input strea.
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append('\n');
            }
            // use the string builder directly,
            // or convert it into a String
            response = sb.toString();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
        }
        return response;
    }
}