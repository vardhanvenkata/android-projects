package com.vardhancreations.login_sharedpreferencedemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private EditText etUName;
    private EditText etPass;
    private Button btReset;
    private Button btLogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etUName = findViewById(R.id.etUName);
        etPass = findViewById(R.id.etPass);
        btLogin = findViewById(R.id.btLogin);
        btReset = findViewById(R.id.btReset);
        btLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String strUName = etUName.getText().toString().trim();
                String strPass = etPass.getText().toString().trim();
                SharedPreferences preferences = getSharedPreferences("datastore", MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("Name", strUName);
                editor.putString("pass", strPass);
                editor.apply();
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                startActivity(new Intent(MainActivity.this, SecondActivity.class));
            }
        });
    }
}