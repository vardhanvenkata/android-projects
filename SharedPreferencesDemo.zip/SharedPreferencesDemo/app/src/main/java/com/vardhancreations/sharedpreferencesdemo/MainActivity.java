package com.vardhancreations.sharedpreferencesdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btNext = findViewById(R.id.btNext);
        findViewById(R.id.btNext2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SecondActivity.class));
            }
        });
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences preferences = getSharedPreferences("datastore", MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("Name", "Android");
                editor.putInt("age", 12);
                editor.apply(); // saves the changes
//                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                startActivity(new Intent(MainActivity.this, FirstActivity.class));
            }
        });
    }
}