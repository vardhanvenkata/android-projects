package com.vardhancreations.fragmentdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView img = findViewById(R.id.imgDownloaded);
        String imgURL = "https://media.geeksforgeeks.org/wp-content/uploads/20210101144014/gfglogo.png";
        Picasso.get()
                .load(imgURL)
                .placeholder(R.mipmap.ic_launcher)
                .error(R.mipmap.logo)
                .into(img, new Callback() {
                    @Override
                    public void onSuccess() {
                        System.out.println("---->Success<----");
                    }

                    @Override
                    public void onError(Exception e) {
                        System.out.println("----> "+e);
                    }
                });
        findViewById(R.id.btNext).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, SecondActivity.class);
                startActivity(intent);
            }
        });
        // Hiding logout option
//        findViewById(R.id.tvLogout).setVisibility(View.GONE);
    }
}