package com.vardhancreations.fragmentdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import org.w3c.dom.Text;

public class FGMTHeader extends Fragment {
    private Activity parentActivity;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View headerView = inflater.inflate(R.layout.header, null);
        TextView tvLogout = headerView.findViewById(R.id.tvLogout);
        TextView tvHome = headerView.findViewById(R.id.tvHome);
        ImageView imgLogo = headerView.findViewById(R.id.imgLogo);
        int unicode = 0x1F60A;
        String emoji = new String(Character.toChars(unicode));
        parentActivity = getActivity(); // getActivity will return the activity to which the fragment is added

        if(parentActivity instanceof LoginActivity) {
            tvLogout.setVisibility(View.GONE);
            tvHome.setVisibility(View.GONE);
        }
        else if(parentActivity instanceof ThirdActivity) {
            tvLogout.setText("Logout" + emoji);
            tvHome.setText("Home " + emoji);
        }
        else if(parentActivity instanceof SecondActivity){
            tvHome.setVisibility(View.GONE);
        }

        imgLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(parentActivity,LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
        tvHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(parentActivity,LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
        tvLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(parentActivity, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });

        return headerView;
    }
}
