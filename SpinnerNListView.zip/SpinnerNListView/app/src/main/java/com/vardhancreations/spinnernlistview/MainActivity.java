package com.vardhancreations.spinnernlistview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

//    private Spinner spinner;
//    private ListView listActivities;
    private Button btAdd;
//    private String[] activities_list = {"Main Activity", "First Activity", "Second Activity", "Third Activity"};
//    private String[] activities={"Select a activity","First Activity","Second Activity","Third Activity"};
//    private ArrayList<String> fruitsList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btAdd = findViewById(R.id.btAdd);
//        spinner = findViewById(R.id.spFruits);
//        listActivities = findViewById(R.id.listActivities);

//        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>
//                (MainActivity.this, android.R.layout.simple_spinner_item, fruits);
//        spinner.setAdapter(arrayAdapter);
//        ArrayAdapter<String> arrayActivityAdapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_spinner_item,activities);
//        spinner.setAdapter(arrayActivityAdapter);
//        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                if(position!=0 && activities[position].equals("First Activity")){
//                    Intent intent = new Intent(MainActivity.this,FirstActivity.class);
//                    startActivity(intent);
//                }
//                else if(position!=0 && activities[position].equals("Second Activity")){
//                    Intent intent = new Intent(MainActivity.this,SecondActivity.class);
//                    startActivity(intent);
//                }
//                else if(position!=0 && activities[position].equals("Third Activity")){
//                    Intent intent = new Intent(MainActivity.this,ThirdActivity.class);
//                    startActivity(intent);
//                }
//                else {
//                    Toast.makeText(MainActivity.this, "Select an Activity", Toast.LENGTH_SHORT).show();
//                }
//            }
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//                Toast.makeText(MainActivity.this, "You can any fruit as you like" , Toast.LENGTH_SHORT).show();
//            }
//        });
//        listActivities.setAdapter(arrayActivityAdapter);
//        listActivities.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                if(position == 0)
//                    Toast.makeText(MainActivity.this, "Select one activity", Toast.LENGTH_SHORT).show();
//                else
//                    Toast.makeText(MainActivity.this, "You selected"+activities_list[position], Toast.LENGTH_SHORT).show();
//            }
//        });
        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,AddActivity.class);
                startActivity(intent);

            }
        });
    }
}