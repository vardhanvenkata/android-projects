package com.vardhancreations.spinnernlistview;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class AddActivity extends AppCompatActivity {
    private EditText first_value,second_value;
    private Button bt_Add;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_activity);
        first_value=findViewById(R.id.first_value);
        second_value=findViewById(R.id.second_value);
        bt_Add=findViewById(R.id.btn_Add);

        bt_Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int first_number= Integer.parseInt(first_value.getText().toString().trim());
                int second_number= Integer.parseInt(second_value.getText().toString().trim());
                Bundle bundle=new Bundle();
                bundle.putInt("firstValue",first_number);
                bundle.putInt("secondValue",second_number);
                Intent intent =new Intent(AddActivity.this,DisplayActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);

            }
        });

    }
}
