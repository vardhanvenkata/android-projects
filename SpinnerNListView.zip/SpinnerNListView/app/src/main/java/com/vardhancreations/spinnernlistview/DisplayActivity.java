package com.vardhancreations.spinnernlistview;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class DisplayActivity extends AppCompatActivity {
    private TextView firstValue,secondValue,result;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display_activity);
        firstValue=findViewById(R.id.firstValue);
        secondValue=findViewById(R.id.secondValue);
        result=findViewById(R.id.result);
        Intent intent=getIntent();
        Bundle bundle =intent.getExtras();
        if(bundle!=null){
            int firstNumber=bundle.getInt("firstValue");
            int secondNumber=bundle.getInt("secondValue");
            int Result=firstNumber+secondNumber;
            firstValue.setText("First Value is "+firstNumber);
            secondValue.setText("Second Value is"+secondNumber);
            result.setText("Result is "+Result);
        }
    }
}
