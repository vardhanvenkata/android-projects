package com.vardhancreations.stepcounter;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.io.*;
import androidx.fragment.app.Fragment;

public class FriendsFragment extends Fragment {

    public FriendsFragment(){
        // require a empty public constructor
    }
    View layoutView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        ListView simpleList;
        String countryList[] = {"                      NAMES                                       STEPS",
                "      NAYANA DHANANJAYA                          3567",
                "      SHRADDHA S GOWDA                             2639 ",
                "      NEHA SYED KOUSAR                               1324",
                "      HARSHA VARDHAN MOTURU                906",
                "      KIRUBAVATHI KUMAR                             834",
                "      VENKATA MERAPUREDDY                      766"};
        int flags[] = {R.drawable.rank,R.drawable.gold, R.drawable.silver, R.drawable.bronz,R.drawable.four,R.drawable.five,R.drawable.sixt};
        layoutView = inflater.inflate(R.layout.fragment_friends, container, false);
        simpleList = (ListView) layoutView.findViewById(R.id.simpleListView);
        CustomAdapter customAdapter = new CustomAdapter(getContext().getApplicationContext(), countryList, flags);
        simpleList.setAdapter(customAdapter);
        return layoutView;
    }
}
