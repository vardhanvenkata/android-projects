package com.vardhancreations.sqllitedemo;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBAdapter extends SQLiteOpenHelper {

    public static final String DB_NAME = "student.db";
    public static final String TBL_STUDENT_NAME = "student";
    public SQLiteDatabase database;
    public static final String CREATE_TABLE_STUDENT = "create table if not exists student" +
            "(rollnum integer not null, name text not null, marks integer, address text)";
    public DBAdapter(@Nullable Context context) {
        super(context, DB_NAME,null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_STUDENT);
    }
    public DBAdapter openDatabase()
    {
//        database = getReadableDatabase(); // Using this Database instance we can only query/read the data
        database = getWritableDatabase(); // Using this Database instance we can query/read and also update the data
        return this;
    }

    public void closeDatabase()
    {
        database.close();
    }
    public boolean addStudent(int rollNumber, String studentName, int studentMarks, String studentAddress)
    {
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", studentName);
        contentValues.put("marks", studentMarks);
        contentValues.put("rollnum", rollNumber);
        contentValues.put("address", studentAddress);
        long rowId = database.insert(TBL_STUDENT_NAME, null, contentValues);
        return rowId > 0;
    }
    
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        System.out.println("Student Database is upgraded from : "+oldVersion+" to : "+newVersion);
    }
}
