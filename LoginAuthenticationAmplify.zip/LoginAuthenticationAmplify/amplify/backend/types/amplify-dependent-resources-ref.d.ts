export type AmplifyDependentResourcesAttributes = {
    "auth": {
        "loginauthentication83bcde7c": {
            "IdentityPoolId": "string",
            "IdentityPoolName": "string",
            "UserPoolId": "string",
            "UserPoolArn": "string",
            "UserPoolName": "string",
            "AppClientIDWeb": "string",
            "AppClientID": "string"
        },
        "userPoolGroups": {
            "vardhanGroupRole": "string"
        }
    },
    "api": {
        "loginauthentication": {
            "GraphQLAPIIdOutput": "string",
            "GraphQLAPIEndpointOutput": "string"
        }
    }
}