package com.vardhancreations.dynamicfragments;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.fragment.app.FragmentManager;

import android.view.VerifiedInputEvent;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.bt1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager manager = getSupportFragmentManager();
                FragmentTransaction addOne = manager.beginTransaction();
                Fragment fragment = new FGMTOne();
                addOne.replace(R.id.container, fragment, "fgmtone");
                addOne.commit();
            }
        });

        findViewById(R.id.bt2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager manager = getSupportFragmentManager();
                FragmentTransaction addTwo = manager.beginTransaction();
                Fragment fragment = new FGMTTwo();
                addTwo.replace(R.id.container, fragment, "fgmttwo");
                addTwo.commit();
            }
        });

        findViewById(R.id.bt3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager manager = getSupportFragmentManager();
                FragmentTransaction addThree = manager.beginTransaction();
                Fragment fragment = new FGMTThree();
                addThree.replace(R.id.container, fragment, "fgmthree");
                addThree.commit();
            }
        });

        findViewById(R.id.bt4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager manager = getSupportFragmentManager();
                FGMTDatePicker fragment = new FGMTDatePicker();
                fragment.show(manager, "Date");
            }
        });

        findViewById(R.id.bt5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager manager = getSupportFragmentManager();
                FGMTClock fragment = new FGMTClock();
                fragment.show(manager, "Time");
            }
        });

        findViewById(R.id.bt6).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager manager = getSupportFragmentManager();
                FGMTAlert fragment = new FGMTAlert();
                fragment.show(manager,"Alert");

            }
        });
    }
}